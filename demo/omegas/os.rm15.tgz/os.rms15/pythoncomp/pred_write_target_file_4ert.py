"""
 Running RMS in batch requires a target file at the end of 
 the workflow for ert to know if it was a success or failure

 rnyb, Apr 21
"""

target_file = "../../RMS_TARGET_PRED"

with open(target_file, "w") as f:
    f.write("OK")

print("Created target file", target_file)
