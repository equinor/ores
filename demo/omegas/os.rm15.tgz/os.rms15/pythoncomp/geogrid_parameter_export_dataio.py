"""
Export geogrid and geogrid parameters (roff format)
Used for both visualization and as input to seismic project

Parameters required/used by seismic project is set in PROPS_SEISMIC
Additional paramters can be set with PROPS_OTHER
All parameters can be used for visualization (coviz)

JRIV
rnyb, Sep 20 - added pathlib for mkdir functionality (can replace all os, but quick fix for now)
rnyb, Oct 20 - gathered all geogrid parameter exports in one script. 
               replaced all instances of os with pathlib
rnyb, May 22 - Added export of Swl parameter needed for the HydraulicFractuerModelling (note: not needed for the standard Drogon workflows)
"""
from pathlib import Path, PurePath

import fmu.dataio as dataio
import xtgeo
from fmu.config import utilities as utils

CFG = utils.yaml_load("../../fmuconfig/output/global_variables.yml")

PRJ = project

GEOGRIDNAME = "GeoGrid"
PROPS_SEISMIC = ["poro", "SW"]
PROPS_OTHER = ["perm", "Regions", "Zone"]


def export_geogrid_parameters():
    """Export geogrid and associated parameters based on user defined lists """

    props = PROPS_SEISMIC + PROPS_OTHER

    edata = dataio.ExportData(
        config=CFG,
        content="depth",
        unit="m",
        vertical_domain={"depth": "msl"},
        workflow="rms grid and property model",
    )

    grd = xtgeo.grid_from_roxar(PRJ, GEOGRIDNAME)
    out = edata.export(grd, name=GEOGRIDNAME)
    print(f"Exported grid as {out}")

    # export properties
    for propname in props:
        prop = xtgeo.gridproperty_from_roxar(PRJ, GEOGRIDNAME, propname)
        out = edata.export(prop, name=propname, parent=GEOGRIDNAME)
        print(f"Exported grid property {propname:>13s}:    {out}")


if __name__ == "__main__":
    export_geogrid_parameters()
    print("Done.")
