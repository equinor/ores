"""
Author akolb: change the variogram based on global variables file
"""
import numpy as np
from fmu.config.utilities import yaml_load
from xtgeo import gridproperty_from_roxar
 
CFG = yaml_load('../input/global_variables/global_variables.yml')['rms']
 
WORKFLOW_NAME = "Laphroaig_Petrophysical_Modelling"
JOB_NAME = "Petrophysical_modelling_NTG_PORO_PERM_Laph"
 
WORKFLOW = project.workflows[WORKFLOW_NAME]
JOB = WORKFLOW.jobs[JOB_NAME]
params = JOB.parameters
 
GRID_NAME = 'Laphroaig'
ZONE_NAME = 'Zone'
 
ZONES = gridproperty_from_roxar(project, GRID_NAME, ZONE_NAME)
ZONE_VALUES = ZONES.values
 
print("Variogram ranges will be set to:\n " +
      f"Horizontal: {CFG['VAR_MAIN_NTG']}\n" +
      f"Horizontal: {CFG['VAR_PERP_NTG']}\n" +
      f"Vertical: {CFG['VAR_VERT']}\n"
)
for nr in np.unique(ZONES.values.compressed()):
    zone = str(nr)
    params.set(['Zone['+zone+']', 'SAND_FLAG', 'VariogramMainRange'], CFG['VAR_MAIN_NTG'])
    params.set(['Zone['+zone+']', 'SAND_FLAG', 'VariogramPerpRange'], CFG['VAR_PERP_NTG'])
    params.set(['Zone['+zone+']', 'SAND_FLAG', 'VariogramVertRange'], CFG['VAR_VERT'])