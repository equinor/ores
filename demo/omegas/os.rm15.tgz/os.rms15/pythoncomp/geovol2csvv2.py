"""Create csv-files from the txt-file output from RMS volumetrics job"""

from fmu.tools.rms.volumetrics import merge_rms_volumetrics
from fmu.config import utilities as ut
CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")

ZONES = CFG["global"]["FACIES_ZONE"]
formnames = list(ZONES.keys())
LIST = CFG["global"]["FWL_DICT"]
REGIONS = list(LIST.keys())
print(REGIONS)
form = []
for i in REGIONS:
   form.append(list(ZONES.keys())[0]) 
print(form)

volfolder = "../../share/results/volumes/"
filebases = ["geogrid_volumes"]


def create_csvfile_with_volumetrics(filebase):

    # create dataframe from rms volumefile     
    rms_volfile = volfolder + filebase    
    df = merge_rms_volumetrics(rms_volfile)
    
    # store dataframe as csvfile    
    output_csvfile = volfolder + filebase + ".csv" 
    if "ZONE" in df.columns:    
        df.to_csv(output_csvfile, index=False)
    else:
        df["ZONE"] = form
        df.to_csv(output_csvfile, index=False)

    print(f"csv-file with volumes stored at {output_csvfile}")


if __name__ == "__main__":

    for filebase in filebases:        
        create_csvfile_with_volumetrics(filebase)

    print("Finished!")