"""Export fault polygons using fmu-dataio.

Using two formats: For use with webviz rftplotter (csv file) and coviz
(pol file). Export via fmu-dataio

Fault polygons are created from "Structural models -> OS_F"F_depth_current -> model_for_grid ->
Extract fault lines..."

rnyb / jriv
"""
import fmu.dataio as dataio
import xtgeo
from fmu.config import utilities as utils

PRJ = project

CFG = utils.yaml_load("../../fmuconfig/output/global_variables.yml")

POL_FOLDER = "ExtractedFaultLines_model_for_grid"
HORIZONNAMES = CFG["rms"]["horizons"]["TOP_RES"]

def _update_name_attribute(poly, hname, folder="DepthPolygons", stype="horizons", poly_attribute="Name"):
    """Update dataframe with additional attribute name for polygons.

    A hack until xtgeo supports attributes from Roxar polygons
    JRIV
    """
    new_poly = poly.copy()
    if stype == "horizons":
        rmspoly = project.horizons[hname][folder]
    elif stype == "zones":
        rmspoly = project.zones[hname][folder]
    else:
        raise ValueError(f"Cannot retrieve data for RMS data folder: {stype}")

    attribute_names = rmspoly.get_attributes_names()
    if poly_attribute not in attribute_names:
        raise ValueError(f"No such attribute name present: {poly_attribute}")

    pvalues = rmspoly.get_attribute_values(poly_attribute)
    named_ids = [pvalues[id] for id in new_poly.dataframe["POLY_ID"]]

    new_poly.dataframe[poly_attribute] = named_ids
    return new_poly

def export_faultlines():
    """Return faultlines as both dataframe and original (xyz)"""

    # see script demo_export_with_fmudataio_readme.py for more details
    edata = dataio.ExportData(
        config=CFG,
        content="depth",
        unit="m",
        vertical_domain={"depth": "msl"},
        workflow="structural_modelling_depth",
    )

    for hname in HORIZONNAMES:
        if project.horizons[hname][POL_FOLDER].is_empty():
            print(f"No data for {hname}: {POL_FOLDER}, will skip")
            continue

        poly = xtgeo.polygons_from_roxar(PRJ, hname, POL_FOLDER)
        print(poly.dataframe)

        # export both csv and irap text format
        for fmt in ["csv", "irap_ascii"]:
            edata.polygons_fformat = fmt
            out = edata.export(poly, name=hname, tagname=POL_FOLDER)
            print(f"Export with metadata to: {out}")


if __name__ == "__main__":
    export_faultlines()
    print("Done!")
