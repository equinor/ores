"""Export well picks as csv file.
The exported file can be used with Webviz MapViewer plugin

hakal/rnyb
"""

from enum import Enum
from typing import List, Optional

import pandas as pd
import roxar

RMS_PROJECT = project
WELL_PICKS_SET = "set1"
WELL_PICKS_FILE = "../../share/results/tables/well_picks.csv"


class WellAttributes(str, Enum):
    """Naming of attributes table/rms"""

    X_UTME = "East"
    Y_UTMN = "North"
    Z_TVDSS = "TVD_MSL"
    MD = "MD"


def horizon_well_picks_to_dataframe(
    project, well_pick_set_name: str, horizon_names_filter: Optional[List[str]] = None
) -> pd.DataFrame:
    well_pick_set = project.well_picks.sets[well_pick_set_name]
    horizon_pick_indexes = []
    horizon_picks = []

    for idx, well_picks in enumerate(well_pick_set):
        horizon_name = well_picks.intersection_object.name
        if well_picks.type == roxar.WellPickType.horizon:
            if horizon_names_filter is not None:
                if horizon_name in horizon_names_filter:
                    horizon_pick_indexes.append(idx)
            else:
                horizon_pick_indexes.append(idx)

    for idx in horizon_pick_indexes:
        pick = well_pick_set[idx]
        well_name = horizon_name = ""
        if pick.trajectory:
            well_name = pick.trajectory.wellbore.well.name
        if pick.intersection_object:
            horizon_name = pick.intersection_object.name
        pick_attributes = {
            attr.name: pick.get_values()[attr.value] for attr in WellAttributes
        }
        pick_attributes.update(
            {
                "WELL": well_name,
                "HORIZON": horizon_name,
            }
        )
        horizon_picks.append(pick_attributes)

    return pd.DataFrame(horizon_picks)


def main() -> None:
    dframe = horizon_well_picks_to_dataframe(RMS_PROJECT, WELL_PICKS_SET)
    dframe.to_csv(WELL_PICKS_FILE, index=False)
    print(f"Exported file {WELL_PICKS_FILE}")


if __name__ == "__main__":
    main()
    print("Done")
