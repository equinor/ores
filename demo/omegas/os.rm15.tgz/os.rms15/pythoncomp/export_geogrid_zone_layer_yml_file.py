"""
 Create yml file with zone and layer info to be used with xtgeo qc scripts
 (GRID3D_HC_THICKNESS and GRID3D_AVG_MAP in ert model file)

 rnyb, Aug 20
"""
from fmu.config import utilities as ut

from pathlib import Path

CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")

GMNAME = CFG["global"]["GEOGRIDNAME"]

ZONE_YML_FILE = Path("../../rms/output/zone/zonation_geo_map.yml")

# --------------------------------


def main():
    """ create yml file with zone-layer info """

    # Retrieve the grid to process:
    grid_model = project.grid_models[GMNAME]
    grid = grid_model.get_grid()

    # Retrieve the zones to process:
    zone_names = grid.zone_names

    ZONE_YML_FILE.parent.mkdir(parents=True, exist_ok=True)
    f = open(ZONE_YML_FILE, "w+")
    f.write("zranges:\n")

    # Loop over all zones in the grid
    for zone_index in range(len(zone_names)):

        # Get layers for zone_index
        layer_ranges = grid.grid_indexer.zonation[zone_index]
        # Convert range to list and add 1 (range starts at 0, we want to start at 1)
        layer_list = [1 + layer_ranges[0][0], 1 + layer_ranges[0][-1]]
        # Write result to file:
        f.write("  - " + zone_names[zone_index] + ": " + str(layer_list) + "\n")

    f.close()


if __name__ == "__main__":
    main()
    print("Done. Created xtgeo compatible yml file", ZONE_YML_FILE)
