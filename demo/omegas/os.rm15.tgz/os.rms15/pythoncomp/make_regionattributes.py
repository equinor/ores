"""
Make region attributes, from FMU config to RMS text format which RMS can import.

By: JRIV
"""

import getpass
import socket
from datetime import datetime
from pathlib import Path
from statistics import mean

import roxar.rms
from fmu.config import utilities as ut

CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")

OUTFOLDER = Path("../output/regions")
OUTPUT_FILE = OUTFOLDER / "regs_fmuconfig.rmsregatt"

OUTFOLDER.mkdir(parents=True, exist_ok=True)

USER = getpass.getuser()
HOST = socket.gethostname()
DTIME = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
RMSVER = roxar.rms.get_version()

# Pc at contacts (owc and goc) is hardcoded to zero, and GCONST is hardcoded
PC_PHASE = 0.0
GCONST = 0.0981


def compute_datum_pressure(goc, fwl):
    """Compute datum pressure at goc for use in EQUIL per segment"""

    ref_depth = CFG["global"]["REF_DEPTH"]
    ref_press = CFG["global"]["REF_PRESSURE"]
    densoil = mean(CFG["global"]["DENSITY"]["OIL"].values())
    denswat = mean(CFG["global"]["DENSITY"]["WATER"].values())
    densgas = mean(CFG["global"]["DENSITY"]["GAS"].values())

    datum_press = (
        ref_press
        + (fwl - ref_depth) * denswat * GCONST
        + (goc - fwl) * densoil * GCONST
    )

    return datum_press


def main():
    """Making the region attributes for RMS based on data from global config"""

    regs = CFG["global"]["REGIONS"]

    with open(OUTPUT_FILE, "w") as fil:
        fil.write("{}{}{}".format("#", "-" * 80, "\n"))
        fil.write(
            "# Made from global variables\n# by {} on {} at {} \n".format(
                USER, HOST, DTIME
            )
        )
        fil.write("{}{}{}".format("#", "-" * 80, "\n"))

        fil.write("RMSREGATT RMS{}\n".format(RMSVER))
        fil.write("UNITSET 'Metric'\n")
        fil.write("CONTACTCAT STANDARD\n")
        fil.write("PHASES GAS OIL WATER\n")
        fil.write("REGATTBEGIN\n")

        for regname, key in regs.items():
            fil.write("\n{}\n".format(key["NUM"]))
            fil.write("NAME='{}'\n".format(regname))
            fil.write("COLOUR={}\n".format(key["COL"]))
            fil.write("GOC={}\n".format(key["GOC"]))
            fil.write("OWC={}\n".format(key["OWC"]))
            fil.write("FWL={}\n".format(key["FWL"]))
            fil.write("PC_GOC={}\n".format(PC_PHASE))
            fil.write("PC_OWC={}\n".format(PC_PHASE))
            fil.write("EQUIL_TYPE={}\n".format(key["EQT"]))
            fil.write("RSVDTAB={}\n".format(key["INITYPE"]))
            fil.write("RVVDTAB={}\n".format(key["INITYPE"]))
            fil.write("RV={}\n".format(key["RV"]))
            fil.write("BGFAC={}\n".format(key["BG"]))

            fil.write("DATUM_DEPTH={}\n".format(CFG["global"]["REF_DEPTH"]))
            fil.write("DATUM_PRES={}\n".format(CFG["global"]["REF_PRESSURE"]))

            # in case of no RSVD tables, we need to set datum depth at goc and compute datum pressure at goc:
            #fil.write("DATUM_DEPTH={}\n".format(key["GOC"]))  # set datum depth at GOC
            #datum_press = compute_datum_pressure(key["GOC"], key["FWL"])
            #fil.write("DATUM_PRES={}\n".format(datum_press))

        fil.write("\nREGATTEND\n")

        print("Generated file:", OUTPUT_FILE)


if __name__ == "__main__":
    main()
