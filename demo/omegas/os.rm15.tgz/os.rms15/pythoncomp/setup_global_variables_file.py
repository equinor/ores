from pathlib import Path
import fmu.config

MASTER = "../../fmuconfig/input/global_master_config.yml"
OUTPUT = "../../fmuconfig/output"
ROOT = "global_variables"

def cleanup():
    for file in Path(OUTPUT).glob(ROOT + "*"):
        file.unlink()
        print(f"Removed old {file}")

def main():
    cfg = fmu.config.ConfigParserFMU()
    cfg.parse(MASTER)

    # Debug: Check if the template path is correct
    print(f"Template path: {OUTPUT}")

    # Make IPL, optional!
    try:
        print("Attempting to generate IPL file...")
        cfg.to_ipl(rootname=ROOT, destination=OUTPUT, template=OUTPUT)
        print("IPL file generated successfully.")
    except Exception as e:
        print(f"Error generating IPL file: {e}")

    # Check if the IPL file exists
    ipl_file = Path(OUTPUT) / f"{ROOT}.ipl.tmpl"
    if ipl_file.exists():
        print(f"IPL file exists at: {ipl_file}")
    else:
        print(f"IPL file does not exist at: {ipl_file}")

    # YAML
    try:
        print("Attempting to generate YAML file...")
        cfg.to_yaml(rootname=ROOT, destination=OUTPUT, template=OUTPUT)
        print("YAML file generated successfully.")
    except Exception as e:
        print(f"Error generating YAML file: {e}")

    print("\n\nGlobal IPL and YML are updated")

if __name__ == "__main__":
    cleanup()
    main()