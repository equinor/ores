#this script gets the OWC from the global_variables.yml file and sets the SW to SW #above the contact and to 0.1 below. OWC is modified in ert. 
#ANISV, sept-24

import roxar
import fmu.config.utilities as utils
import numpy as np
import xtgeo


# Load the configuration
cfg = utils.yaml_load('../../fmuconfig/output/global_variables.yml')
cfg_rms = cfg['rms']
OWC = cfg_rms['OWC']

GRID = 'GeoGrid'

# Extract the Cell_Z and SW property
sw = xtgeo.gridproperty_from_roxar(project, GRID, 'SW')
cell_z = xtgeo.gridproperty_from_roxar(project, GRID, 'Cell_Z')


# Apply the logic to each cell
sw.values[cell_z.values > OWC] = 0.1

# store to another icon
sw.to_roxar(project, GRID, "SW_ECL")