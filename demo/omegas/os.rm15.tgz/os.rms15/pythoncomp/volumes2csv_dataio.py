"""Compute volumes and generate CSV files, using tables and pandas in RMS.

I.e. there is no dependency of exported (and with unstable format) Excel files

Note, for "old" versions not using dataio, and are parsing spreasheet data, see
* OLD_geovol2csv.py
* OLD_simvol2csv.py

JRIV
"""

import fmu.dataio as dataio
import pandas as pd
from fmu.config import utilities as ut

CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")

PRJ = project
VOLTABLES = {"geogrid": "geogrid_volumes"}

RENAME = {
    "Proj. real.": "REAL",
    "Zone": "ZONE",
    "Segment": "REGION",
    "Boundary": "LICENSE",
    "Facies": "FACIES",
    "BulkOil": "BULK_OIL",
    "NetOil": "NET_OIL",
    "PoreOil": "PORV_OIL",
    "HCPVOil": "HCPV_OIL",
    "STOIIP": "STOIIP_OIL",
    "AssociatedGas": "ASSOCIATEDGAS_OIL",
    "BulkGas": "BULK_GAS",
    "NetGas": "NET_GAS",
    "PoreGas": "PORV_GAS",
    "HCPVGas": "HCPV_GAS",
    "GIIP": "GIIP_GAS",
    "AssociatedLiquid": "ASSOCIATEDOIL_GAS",
    "Bulk": "BULK_TOTAL",
    "Net": "NET_TOTAL",
    "Pore": "PORV_TOTAL",
}


def get_voltable(name):
    """From RMS table to dataframe."""
    table = PRJ.volumetric_tables[name]
    dict_values = table.get_data_table().to_dict()
    dfr = pd.DataFrame.from_dict(dict_values)
    return dfr


#def process_and_store(name, dfr):
    """Do some changes in the dataframe and store via fmu-dataio."""
    dfr.rename(columns=RENAME, inplace=True)
    dfr.drop("REAL", axis=1, inplace=True)
#
#    edata = dataio.ExportData(
#        config=CFG,
#        content="volumes",
#        unit="m3",
#        vertical_domain={"depth": "msl"},
#        workflow="rms property model",
#        forcefolder="volumes",  # default is tables, keep volumes as legacy
#        access_ssdl={"access_level": "restricted"},  # volumes are restricted in most assets
#    )
#
#    out = edata.export(dfr, name=name, tagname="vol")
#    print(f"Volume result to: {out}")


def main():
    """Main function"""
    for volname, voltable in VOLTABLES.items():
        dfr = get_voltable(voltable)
#        process_and_store(volname, dfr)


if __name__ == "__main__":
    main()
