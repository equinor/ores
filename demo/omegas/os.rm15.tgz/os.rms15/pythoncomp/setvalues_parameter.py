# Author: Birgir Sigurjonsson
#modified by aug 2024
import roxar
import fmu.config.utilities as utils
import numpy as np

cfg = utils.yaml_load('../../fmuconfig/output/global_variables.yml')
cfg_rms = cfg['rms']
grid_name = cfg['global']['GEOGRIDNAME']
param_dict = { 'NTG':cfg_rms['NTG'],
               'SW':cfg_rms['SW']
             }
zone_param_name = 'Zone'

real = project.current_realisation

grid_model = project.grid_models[grid_name]
grid = grid_model.get_grid(realisation=real)
zone_values = grid_model.properties[zone_param_name].get_values(realisation=real)

for param_name, value in param_dict.items():
    print(f'Processing property: {param_name}')
    param = grid_model.properties[param_name]
    param_vals = param.get_values(realisation=real)
    for zone_number in grid.grid_indexer.zonation:
        zone_name = grid.zone_names[zone_number]
        print(f'  Processing zone: {zone_name} {zone_number}  {param_name} {value[zone_number]}')
        param_vals[zone_values==zone_number+1] = value[zone_number]
    param.set_values(param_vals)


#
print('Finished!')
