'''
RREM@equinor.com
19.08.2021

This script was modified from drogon script"read_2d_table.py in order to read dictionaries from the global_config of the Njord Field and store them in form of tables that can be used in the water saturation or volumetrics jobs.

'''


import numpy as np
import pandas as pd
from fmu.config import utilities as ut

PRJ = project

CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")

PARAMETER=["FWL"]


def main():
    for para in PARAMETER:  
        x=para
        print(x)
        y="_DICT"
        LIST = CFG["global"][x+y]
        #REG = CFG["global"]["REGIONS"]
        FORM= CFG["global"]["FACIES_ZONE"]
        

        REGIONS = list(LIST.keys())  

        formnames = list(FORM.keys())
        print(REGIONS, formnames)
        df = pd.DataFrame()
    

        for i in REGIONS:
            arr = []
        
            for j in formnames:
                arr.append(LIST[i][j])
            print(arr)

            table = PRJ.tables.create(x)
            df0 = pd.DataFrame([arr], columns=formnames, index=[i])
            df=df.append(df0)
        print(df)
        df=df.T   
        print(df)
        table.set_values(df)
        print(f"Jobs configuration is done, the results may be found in the RMS Data tree under Library > Tables > {para}.")


if __name__ == "__main__":
    main()