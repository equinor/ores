# Create various parameters needed for calculating Sw and volumes
# 2021-05-28  CGK

# copied from Irpa - glesc 19.02.2024

import roxar
import xtgeo
from fmu.config import utilities as ut


# Make link to global_variables
CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")["global"] #Notice here that the parameter is called from the global section of the .yml file!!


# Define parameters
PRJ = project
GNAME = 'GeoGrid'  # Alternative: get grid name from global_variables: CFG["global"]["GEOGRIDNAME"]
DNAME = 'Cell_Z'
FWLSNAME = 'FWL_swirr'


def create_fwl_swirr():

    depth = xtgeo.gridproperty_from_roxar(PRJ, GNAME, DNAME)

    fwl_swirr = depth.copy() # Create starting point 

    # Manipulate value for all regions:
    fwl_swirr.values[()] = fwl_swirr.values[()] + 300.0 # I dont remember the value you use for Asterix here...

    # Save parameter 
    fwl_swirr.to_roxar(PRJ, GNAME, FWLSNAME)
    print('does not seem to do that-->Created FWL parameter for swirr calculation based on cell depth and ~ 1.5 x HC column height:', '\n',
        'does this instead --->For all regions used: cell depth + 300', 
        'Done')

if __name__ == "__main__":
    create_fwl_swirr()
