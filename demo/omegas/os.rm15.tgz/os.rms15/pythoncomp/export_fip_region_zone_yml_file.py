"""FIPNUM vs Region and Zones in YAML file.

Create yml file with fipnum region and zone info to be used in Webviz for
ReservoirSimulationTimeSeriesRegional, but also other tools like PRT2CSV.

The result of this will hardly change from setup tp setup, but in case
the script here will inherit changes in zones, regions, etc

COTT, Sep 20
JRIV, xtgeo version
"""

from pathlib import Path
from fmu.config import utilities as ut
import numpy as np
import xtgeo
import yaml

PRJ = project
CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")
GMNAME = CFG["global"]["ECLGRIDNAME"]
FNAME = "FIPNUM"
RNAME = "Regions"
ZNAME = "Zone"
FIP_YML_FILE = Path("../../share/results/tables/fip.yml")

# --------------------------------


def main():
    """ create yml file with zone-layer info """
    fipnum = xtgeo.gridproperty_from_roxar(PRJ, GMNAME, FNAME)
    region = xtgeo.gridproperty_from_roxar(PRJ, GMNAME, RNAME)
    zone = xtgeo.gridproperty_from_roxar(PRJ, GMNAME, ZNAME)

    rtable = {}
    for codeval, regname in region.codes.items():
        rtable[regname] = np.ma.unique(fipnum.values[region.values == codeval]).tolist()

    ztable = {}
    for codeval, zonname in zone.codes.items():
        ztable[zonname] = np.ma.unique(fipnum.values[zone.values == codeval]).tolist()

    fip = {"FIPNUM": {"groups": {"REGION": rtable, "ZONE": ztable}}}

    FIP_YML_FILE.parent.mkdir(parents=True, exist_ok=True)

    with open(FIP_YML_FILE, "w") as stream:
        yaml.dump(fip, stream)


if __name__ == "__main__":
    main()
    print("Done. Created file", FIP_YML_FILE)
