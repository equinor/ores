"""
Compute KV from given Kv/Kh ratios per facies
Author: JRIV
"""

import roxar
import xtgeo
from fmu.config import utilities as ut

print("Roxar version is", roxar.__version__)
print("XTGeo version is", xtgeo.__version__)

CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")


PRJ = project
ZNAME = CFG["global"]["GEOGRIDNAME"]
KHNAME = "KLOGH"
KVNAME = "KV"
FNAME = "FACIES"

KVKH = CFG["global"]["KVKH"]


def main():
    kh = xtgeo.gridproperty_from_roxar(PRJ, ZNAME, KHNAME)
    fac = xtgeo.gridproperty_from_roxar(PRJ, ZNAME, FNAME)

    kv = kh.copy()
    print("Average KH is", kh.values.mean())

    for faciescode in CFG["global"]["FACIES"].keys():
        kv.values[fac.values == faciescode] *= KVKH[faciescode]

    print("Average KV is", kv.values.mean())

    kv.to_roxar(PRJ, ZNAME, KVNAME)
    print("Made KV property, store icon: ", KVNAME)


if __name__ == "__main__":
    main()
