"""
    Convert excel volume files exported from rms volumetrics job to csv files. 
    0 decimals in output and dropping rows with Totals

    rnyb, Aug 20
    stcr, 20210906
"""

import pandas as pd


######## USER SETTINGS #####################

# rms volumetrics files (excel)
oil_excel = "../../share/results/volumes/geogrid_vols_oil_1.xls"

# csv files to be created
oil_csvfile = "../../share/results/volumes/geogrid--vol.csv"


######## MAIN ##############################

df_oil = pd.read_excel(oil_excel, header=13, engine= 'xlrd')

print (df_oil)
df_oil.rename(
    columns={
        "Real": "REAL",
        "Zone": "ZONE",
        "Region index": "REGION",
        "Bulk": "BULK",
        "Pore": "PORE",
        "Net": "NET",
        "Hcpv": "HCPV",
        "Stoiip": "STOIIP",
        "Assoc.Gas": "ASSOCIATEDGAS",
    },
    inplace=True,
)

print (df_oil)
# Get names of indexes for which column ZONE or REGION is Totals
index_names_oil = df_oil[
    (df_oil["ZONE"] == "Totals") | (df_oil["REGION"] == "Totals")
].index
# Delete these row indexes from dataFrame
df_oil.drop(index_names_oil, inplace=True)

df_oil.to_csv(oil_csvfile, index=False, float_format="%.0f")

print("\nCreated file", oil_csvfile, ":\n", df_oil.head(2))
print("Done")
