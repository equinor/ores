"""
Export of surfaces for use with coviz or webviz
Surfaces to export are given in SURFNAMES variable
Surface folder is given in ATTRS variable
JRIV

ANISV, June 24: adapted script to this project
"""

import fmu.dataio as dataio
import xtgeo
from fmu.config import utilities as ut

print(f"Using xtgeo version {xtgeo.__version__} and fmu.dataio version {dataio.__version__}");

PRJ = project

#sys.path.insert(0, PRJ.filename + "/pythoncomp")
#import lib_project

CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")

ATTRS = ["ExtractedHorizon_model_for_grid"]
SURFNAMES = CFG["rms"]["horizons"]["TOP_RES"]


def main():

    edata = dataio.ExportData(
        config=CFG,
        content="depth",
        unit="m",
        workflow="rms structural model",
    )

    for attr in ATTRS:
        for surfname in SURFNAMES:
            if PRJ.horizons[surfname][attr].is_empty():
                print(f"Empty surface {surfname}:{attr}... skip!")
                continue

            srf = xtgeo.surface_from_roxar(PRJ, surfname, attr)

            out = edata.export(srf, name=surfname, tagname=attr)
            print(f"Export to {out}")


if __name__ == "__main__":
    main()
