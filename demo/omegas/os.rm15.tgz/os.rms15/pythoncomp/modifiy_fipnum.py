'''change fipnum from 1 to 2
lx 2024.03.19
'''



import fmu.config.utilities as utils
import xtgeo
import numpy as np

CFG = utils.yaml_load("../../fmuconfig/output/global_variables.yml")["global"]
PRJ = project


# Presets
gm_name = CFG["GEOGRIDNAME"]
fip_name = "FIPNUM"
depth_name = "Cell_Z"
regions = CFG["REGIONS"]

def main():
    # Get the grid
    grd = xtgeo.grid_from_roxar(PRJ, gm_name)

    # Get already existing parameters from Geogrid
    depth = xtgeo.gridproperty_from_roxar(PRJ, gm_name, depth_name)
    owc = 3672
    fipnum = xtgeo.gridproperty_from_roxar(PRJ, gm_name, fip_name)

    fipnum.values[depth.values>=owc] = 2
    fipnum.to_roxar(PRJ, gm_name, fip_name)

if __name__ == "__main__":
    main()
    print(">> Finished modifying fipnum from 1 to 2")