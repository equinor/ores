"""
 Set PORO to 0 if pore volume of a cell is less than a minpv threshold
 minpv is read from the global variable file

 Note that the effect of minpv is sensitive to the grid resolution
 Script is set up to scale the minpv value according to dx*dy
 scaled minpv = minpv * (dx*dy)/(100*100);  i.e. scaling is 1 for 150*150
"""

import fmu.config.utilities as utils
import xtgeo

print("xtgeo version:", xtgeo.__version__)

# ------------------------------------
# user settings
# ------------------------------------

CFG_GLOBAL = utils.yaml_load("../../fmuconfig/output/global_variables.yml")["global"]

PRJ = project
GMNAME = "Simgrid"  # grid name
TOTALBULKNAME = "Total_bulk"  # total bulk volume parameter name
PORONAME = "PORO"  # porosity parameter name

MINPV = CFG_GLOBAL["SIMGRID_MINPV"]
# ------------------------------------


def edit_poro():
    grd = xtgeo.grid_from_roxar(project, GMNAME)
    dx, dy = grd.get_dxdy(asmasked=True)
    scaled_minpv = MINPV * (dx.values * dy.values) / (100 * 100)

    tbulk = xtgeo.gridproperty_from_roxar(PRJ, GMNAME, TOTALBULKNAME)
    poro = xtgeo.gridproperty_from_roxar(PRJ, GMNAME, PORONAME)

    poro.values[(tbulk.values * poro.values < scaled_minpv)] = 0.0
    poro.to_roxar(PRJ, GMNAME, PORONAME)
    print(
        "Setting poro = 0 (overwrite) for cells with (scaled) porv < "
        + str(MINPV)
        + ". \nDone"
    )


# ------------------------------------
# main
# ------------------------------------

if __name__ == "__main__":
    edit_poro()
