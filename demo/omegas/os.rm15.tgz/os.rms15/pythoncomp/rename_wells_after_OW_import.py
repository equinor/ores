"""
#
# NAME:
#    rename_wells.py
#
# AUTHOR(S):
#    Jan C. Rivenaes
#
# DESCRIPTION:
#    Wellbore data loaded from OW link or from files can have wellbore names
#    with characters not accecpted in RMS
#    Rename wells from "xx/yy-x xx" form to "xx_yy-x_xx" form, and rename
#    trajectory name from Imported to Drilled
#
# TODO/ISSUES/BUGS:
#
# LICENCE:
#     Equinor property
#
# CODING STANDARD:
#    PEP8
#
# Modified for Snorre data 
#    replace("/", "_")
#    replace(" ", "_")
#
"""

import rmsapi
import copy

print('Number of wells: {}'.format(len(project.wells)))

# loop over wells
wells_renamed = 0
total_drilled = 0
#total_planned = 0

for well in project.wells:

    wname = well.name
    newname = copy.deepcopy(wname)

    newname = newname.replace("/", "_")
    newname = newname.replace(" ", "_")
    #print("=" * 60)
    print("Well name was {}, new name is {}".format(wname, newname))

    if wname.startswith('34'):
        print(wname)
        total_drilled += 1
        
        if wname != newname:
            well.name = newname
            wells_renamed += 1

        oldtraj = "Imported trajectory"
        newtraj = "Drilled trajectory"

        if oldtraj in well.wellbore.trajectories:
            well.wellbore.trajectories[oldtraj].name = newtraj
        elif wname.startswith('dummy'):
            pass
        else:
            print('PLANNED WELL')


        if wname != newname:
            well.name = newname
            wells_renamed += 1

        total_drilled += 1
        newtraj = "Planned trajectory"
        oldtraj = 'Imported trajectory'
        if oldtraj in well.wellbore.trajectories:
            well.wellbore.trajectories[oldtraj].name = newtraj
 
print('Total wells: {}'.format(total_drilled))
#print('Planned wells {}'.format(total_planned))
#print('Total wells {}'.format(total_planned + total_drilled))

print('Renamed {}'.format(wells_renamed))