import rmsapi
import xtgeo
from fmu.config import utilities as ut
"""
º,º
"""
 
GLOBAL_VARIABLES = ut.yaml_load("../../fmuconfig/output/global_variables.yml")
OWC              = GLOBAL_VARIABLES["rms"]["OWC"]

grid_name               = "GeoGrid"
workflow_name           = "volumetrics"
name_of_volumetrics_job = "volumetrics_os"
 
 
wf      = project.workflows[workflow_name]
job     = wf.jobs[name_of_volumetrics_job]
job_settings = rmsapi.jobs.Job.get_job(owner=['Grid models', grid_name, 'Grid'],
                                    type="Volumetrics",
                                    name=name_of_volumetrics_job).get_arguments()
 
contact_saved_in_vol_job = job_settings['Variables'][0]['Oil Variables'][0]['TableValues']
if contact_saved_in_vol_job != OWC:
    fyi = f"""
    OWC in global_variables.yml : {OWC} m
    Will update job '{name_of_volumetrics_job}' from {contact_saved_in_vol_job} m to {OWC} m.
    """
    print(fyi)
    job.parameters.set(['OilWaterContact'], OWC)