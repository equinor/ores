"""Make zone layer tables.

Create a text table with the zone associated with each layer of a 3D grid. Export of
zone-layer info as part of the main workflow to ensure consistency when running ERT
(gendata_rft) (gendata_rft keyword should be set up to point to this file)

In addition to RMS output, the files are exported to share/... and potentially SUMO
with fmu.dataio

JRIV/JIZ/RNYB
"""
from pathlib import Path

import fmu.dataio as dio
import pandas as pd
from fmu.config import utilities as ut

PRJ = project

CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")

GRID_NAME = CFG["global"]["ECLGRIDNAME"]
FILE_NAME = "layer_zone_table"
FILE_PATH = Path("../../rms/output/zone/")


def zone_layer_table():
    """Create a zone-layer table for the actual realization."""
    # using Roxar python API:
    grid = PRJ.grid_models[GRID_NAME].get_grid()
    indexer = grid.grid_indexer
    n_layers = indexer.dimensions[2]
    zone_names = grid.zone_names

    layers = []
    zones = []

    for klayer in range(n_layers):
        zone_name = "FAIL"
        for zone_index in indexer.zonation:
            for layer_interval in indexer.zonation[zone_index]:
                # More than one group of layers only if repeat sections in the grid
                if klayer in layer_interval:
                    zone_name = zone_names[zone_index]
                    layers.append(klayer + 1)  # layer counting starts with 1, not 0
                    zones.append(zone_name)
    dataframe = pd.DataFrame({"LAYER": layers, "ZONE": zones})
    return dataframe


def write_to_rms_output(dataframe):
    """Write result to RMS output / zone area."""
    fname1 = FILE_PATH / (FILE_NAME + ".csv")
    fname2 = FILE_PATH / (FILE_NAME + ".txt")
    dataframe.to_csv(fname1, index=False)

    # using to_csv() with modifiers for the text files:
    dataframe.to_csv(fname2, sep=" ", header=None, index=False)

    print(f"Export to: <{fname1}> and <{fname2}>")

def export_dataio(dataframe):
    """Export the Pandas table with fmu.dataio."""
    edata = dio.ExportData(config=CFG, name=FILE_NAME, description="Layer vs zone correspondance", )

    out = edata.export(dataframe)
    print("Dataio export to:", out)

def main():
    """Main entry point."""
    dataframe = zone_layer_table()
    write_to_rms_output(dataframe)
    export_dataio(dataframe)


if __name__ == "__main__":
    main()
