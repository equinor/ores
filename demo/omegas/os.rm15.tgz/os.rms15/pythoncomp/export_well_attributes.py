"""
Exports well attributes as a json file.

This is intended to be used in the WellCompletions Webviz plugin (and possibly other plugins)

The format is agreed with Emerson. There is plans
to make it possible to export this with an internal RMS job. I have 
therefore hardcoded it here as a temporary solution.

olind - sep 2021

"""
import json
from pathlib import Path

PATH = "../../rms/output/wells/"
FILENAME = "well_attributes.json"

WELL_ATTRIBUTES = {
    "version" : "0.1",
    "wells" : [
        {
           "alias" : {
              "eclipse" : "A1"
            },
            "attributes" : {
            "welltype" : "oil producer"
            },
            "name" : "A1"
        },
        {
            "alias" : {
               "eclipse" : "A2"
            },
            "attributes" : {
                "welltype" : "oil producer"
            },
            "name" : "A2"
        },
        {
            "alias" : {
               "eclipse" : "A3"
            },
            "attributes" : {
                "welltype" : "oil producer"
             },
             "name" : "A3"
         },
         {
            "alias" : {
               "eclipse" : "A4"
            },
            "attributes" : {
            "welltype" : "oil producer"
            },
            "name" : "A4"
        },
        {
            "alias" : {
               "eclipse" : "A5"
            },
            "attributes" : {
                "welltype" : "water injector"
            },
            "name" : "A5"
        },
        {
            "alias" : {
               "eclipse" : "A6"
            },
            "attributes" : {
                "welltype" : "water injector"
            },
            "name" : "A6"
        },
        {
            "alias" : {
               "eclipse" : "R_A1"
            },
            "attributes" : {
                "welltype" : "observation well"
            },
            "name" : "R_A1"
        },
        {
            "alias" : {
                "eclipse" : "R_A2"
            },
            "attributes" : {
                "welltype" : "observation well"
            },
            "name" : "R_A2"
        },
        {
            "alias" : {
                "eclipse" : "R_A3"
            },
            "attributes" : {
                "welltype" : "observation well"
            },
             "name" : "R_A3"
        },
        {
            "alias" : {
                "eclipse" : "R_A4"
            },
            "attributes" : {
                "welltype" : "observation well"
            },
            "name" : "R_A4"
        },
        {
            "alias" : {
               "eclipse" : "R_A5"
            },
            "attributes" : {
                "welltype" : "observation well"
            },
            "name" : "R_A5"
        },
        {
            "alias" : {
                "eclipse" : "R_A6"
            },
            "attributes" : {
            "welltype" : "observation well"
            },
            "name" : "R_A6"
        }
    ]
 }

if __name__ == "__main__":
    filepath = Path(PATH + FILENAME) 
    
    # Create folder if it doesn't exist
    filepath.parent.mkdir(parents=True, exist_ok=True)

    # Export file
    with open(filepath, "w") as handle:
        json.dump(WELL_ATTRIBUTES, handle, indent=4)
    
    print(f"Exported file: {str(filepath)}")