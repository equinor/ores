'''Clean Sw a little bit
made by iazi
'''



import fmu.config.utilities as utils
import xtgeo
import numpy as np

CFG = utils.yaml_load("../../fmuconfig/output/global_variables.yml")["global"]
PRJ = project


# Presets
gm_name = CFG["GEOGRIDNAME"]
perm_name = "KLOGH"
poro_name = "PHIT"
swj_name = "Sw"
swirr_name = "Swirr"
gwc_swirr_name = "FWL_Swirr"
gwc_name = "FWL"
zone_name = "Zone"
depth_name = "Cell_Z"
facies_name = "FACIES"

# Get the grid
grd = xtgeo.grid_from_roxar(PRJ, gm_name)

# Get already existing parameters from Geogrid
poro = xtgeo.gridproperty_from_roxar(PRJ, gm_name, poro_name)
perm = xtgeo.gridproperty_from_roxar(PRJ, gm_name, perm_name)
zone = xtgeo.gridproperty_from_roxar(PRJ, gm_name, zone_name)
depth = xtgeo.gridproperty_from_roxar(PRJ, gm_name, depth_name)
gwc = xtgeo.gridproperty_from_roxar(PRJ, gm_name, gwc_name)
facies = xtgeo.gridproperty_from_roxar(PRJ, gm_name, facies_name)
swj = xtgeo.gridproperty_from_roxar(PRJ, gm_name, swj_name)
swirr = xtgeo.gridproperty_from_roxar(PRJ, gm_name, swirr_name)

# Postprocessing: Setting SwJ = 1 in water zone
#if depth >= gwc:
#    swj = 1
swj.values[depth.values>=gwc.values]=1


#if swj > 1:
#    swj = 1
swj.values[swj.values>1]=1

#if swj < 0.01:
#    swj = 0
swj.values[swj.values<0.01]=0

#if swirr > 0.9:    
#    swirr = 0.25
swirr.values[swirr.values>0.68]=0.67

#if swirr > swj:
#    swirr = swj

swirr.values = np.where(swirr.values > swj.values, swj.values, swirr.values)




#if Depth < 3188.5: this was used to test volumetics, not needed for saturation modelling
#    swj = 0.368
#swj.values[depth.values<3188.5]=0.4

swj.to_roxar(PRJ, gm_name, swj_name)
swirr.to_roxar(PRJ, gm_name, swirr_name)

print(">> Finished!")
