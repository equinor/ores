"""
Rename wells

Wells nomenclature includes special characters such as "/", " ",  "-" etc. These characters have been 
known to sometimes create problems in rms. The wells are therefore renamed in rms, such that special
characters are replaced with an underscore "_"

cba (modified for Garantiana, cela, 04 2021)
"""
import roxar

# Run through the wells and rename them so that "/" and " " are replaced by "_"
for well in project.wells:
    wn=well.name
    wn=wn.replace("/","_")
    wn=wn.replace(" ","_")
    wn=wn.replace("-","_")
    well.name=wn

print('Script finished')