# This script modifies the mean for both porosity and permeability in the petrophysical job "prop_withdepthtrend" from the global_master.yml.tmpl files when ert is run. Script is ready for varying variograms if that is needed in the future.
# ANISV, sept -24
# bisi, changed the script to use the Job module

import roxar
import roxar.jobs
import fmu.config.utilities as utils
import numpy as np
import pprint

# Load global configuration values from the specified YAML file
CFG_GLOBAL = utils.yaml_load('../../fmuconfig/output/global_variables.yml')['rms']


def main():
    gm_name =  'GeoGrid'

    petro_job = roxar.jobs.Job.create(owner=['Grid models', gm_name, 'Grid'],
                                  type='Petrophysical Modeling',
                                  name='prop_withdepthtrend')

 # Retrieve the current parameters of the job
    params = petro_job.get_arguments()

 # Get the grid for the specified grid model and current realisation
    grid = project.grid_models[gm_name].get_grid(realisation=project.current_realisation)
    zone_names = grid.zone_names # Get the names of the zones in the grid
 
# Loop through each zone model and update the mean values for porosity and permeability
    for zone_no in range(len(params['Zone Models'])):
        print(f"Updating {zone_names[zone_no]}")
        print(f"PORO = {CFG_GLOBAL['PORO'][zone_no]} PERM = {CFG_GLOBAL['PERMX'][zone_no]}" )

# Update the mean value for porosity in the current zone model
        params['Zone Models'][zone_no]['Facies Models'][0]['Variable Models'][0]['Transform Sequence'][0]['Mean'][0]['Mean'] = CFG_GLOBAL['PORO'][zone_no]

# Update the mean value for permeability in the current zone model
        params['Zone Models'][zone_no]['Facies Models'][0]['Variable Models'][1]['Transform Sequence'][0]['Mean'][0]['Mean'] = np.log10(CFG_GLOBAL['PERMX'][zone_no])   

# Update the variogram ranges in the current zone model
#        variogram_ranges = CFG_GLOBAL['VARIOGRAM_RANGES'][zone_no]
#        params['Zone Models'][zone_no]['Facies Models'][0]['Variable Models'][0]['Transform Sequence'][0]['Variogram']#[0]['Ranges'] = variogram_ranges
#        params['Zone Models'][zone_no]['Facies Models'][0]['Variable Models'][1]['Transform Sequence'][0]['Variogram']#[0]['Ranges'] = variogram_ranges

# store the updated parameters back to the job    
    petro_job.set_arguments(params)
    # save the job
    petro_job.save()

if __name__ == "__main__":
    main()
