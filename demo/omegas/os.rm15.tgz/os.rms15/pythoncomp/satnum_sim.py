"""
    Create SATNUM parameter for eclipse with vertical split (scal recommended practice)
        input is satnum without vertical split, output is satnum with vertical split

    Split criteria for each satnum is read from global variable file
        variables read from global variable file are expected to be of type dictionary
        (update the fmuconfig file if they are not)

    Code names assigned to the new satnum is read from global variable file


  Author: rnyb, Apr 20
"""

import math
import numpy as np

import fmu.config.utilities as utils
import xtgeo

print("xtgeo version:", xtgeo.__version__)

# ------------------------------------
# user settings
# ------------------------------------
PRJ = project


SW = "Sw"  # input Sw
SOUTNAME = "SATNUM_GEOGRID"  # output satnum (with vertical split)


CFG = utils.yaml_load("../../fmuconfig/output/global_variables.yml")["global"]
print(CFG)
GMNAME = CFG["GEOGRIDNAME"]  # input grid mode
# ------------------------------------
# functions
# -------------------------------------------------------

def make_satnum_split():
    """
    Main function for splitting satnum vertically in 2 parts
        --> doubling of satnum regions
    Split criteria is sw value read from global variable file
    """
    # read 3d parameters
    water_sat = xtgeo.gridproperty_from_roxar(PRJ, GMNAME, SW)

    # create new satnum parameter, use input satnum as start point
    sout = water_sat.copy()
    sout.name = SOUTNAME
    print(type(sout))
    print("Running script for splitting satnum vertically...")
    print("Name of input satnum parameter (without split):", SW)
    print("Name of output satnum parameter to be created (with split):", SOUTNAME)
    print("Work in progress...")

    # ---------------------------------------------
    # read split criteria from globvar
    satnum_split_sw = CFG["SATNUM_SPLIT_SW"]
    print(satnum_split_sw)
    
    sout.values = np.where(water_sat.values > satnum_split_sw, 2, 1)
    # store new satnum parameter
    sout.to_roxar(PRJ, GMNAME, SOUTNAME)

    print("Done. Created parameter:", SOUTNAME)
    print(type(sout))
# ------------------------------------
# main
# ------------------------------------

if __name__ == "__main__":
    make_satnum_split()
