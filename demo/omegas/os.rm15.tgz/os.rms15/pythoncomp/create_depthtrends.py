#creates depth trends for porosity and permeability

import fmu.config.utilities as utils
import roxar

# Load global configuration values from the specified YAML file
CFG_GLOBAL = utils.yaml_load('../../fmuconfig/output/global_variables.yml')

# Define the parameters
gm_name = "GeoGrid"
zone_name = "Zone"
phinet_dtrend_name = "PhiNet_DepthTrend"
khnet_dtrend_name = "KhNet_DepthTrend"
depth_name = "Cell_Z"

# Core porosity and permeability slopes versus depth
a = -0.00008
b = -0.0001

# Adjust slopes if PORO_DTREND_SIM is set
if CFG_GLOBAL['PORO_DTREND_SIM'] == 1:
    a = CFG_GLOBAL['PORO_DT'] / 1000
    b = CFG_GLOBAL['PERM_DT'] / 1000

datum = 3500

# Get the grid model and parameters
project = roxar.Project.open("os_wdepthtrend.rms13.1.2")
gm = project.grid_models[gm_name]
zone = gm.parameters[zone_name]
depth = gm.parameters[depth_name]

print("script running.....")

# Create continuous parameters for depth trends
phinet_dtrend = roxar.Parameter.create_continuous(gm)
khnet_dtrend = roxar.Parameter.create_continuous(gm)

# Initialize depth trends
phinet_dtrend.set_all(0)
khnet_dtrend.set_all(0)

# Update depth trends based on zone
for i in range(len(zone)):
    if zone[i] == 1:
        phinet_dtrend[i] = (depth[i] - datum) * a
        khnet_dtrend[i] = (depth[i] - datum) * b
    elif zone[i] == 2:
        phinet_dtrend[i] = (depth[i] - datum) * a
        khnet_dtrend[i] = (depth[i] - datum) * b
    elif zone[i] == 3:
        phinet_dtrend[i] = (depth[i] - datum) * a
        khnet_dtrend[i] = (depth[i] - datum) * b
    elif zone[i] == 4:
        phinet_dtrend[i] = (depth[i] - datum) * a
        khnet_dtrend[i] = (depth[i] - datum) * b
    elif zone[i] == 5:
        phinet_dtrend[i] = (depth[i] - datum) * a
        khnet_dtrend[i] = (depth[i] - datum) * b

# Set parameters in the grid model
gm.parameters[phinet_dtrend_name] = phinet_dtrend
gm.parameters[khnet_dtrend_name] = khnet_dtrend

print("script finished.....")