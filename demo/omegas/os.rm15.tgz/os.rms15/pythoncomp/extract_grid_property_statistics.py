"""
Create file share/results/tables/grid_property_statistics_geogrid.csv for Webviz PropertyStatistics

hakal, Sep 21 - Based on https://equinor.github.io/fmu-tools/qcproperties.html#methods-for-extracting-property-statistics
"""

from fmu.tools import QCProperties

GRID = "GeoGrid"
PROPERTIES = {
    "PORO": {"name": "poro"},
    "PERM": {"name": "perm"},
    "SW": {"name": "SW"},
#    "VSH": {"name": "VSH","weight": "Total_bulk"},
#    "VPHYL": {"name": "VPHYL"},
}
SELECTORS = {
   "REGION": {
        "name": "Regions",
    }, 
    "ZONE": {
        "name": "Zone",
    },
 #   "FACIES": {
 #       "name": "FACIES",
 #   }
}
REPORT = "../../share/results/tables/grid_property_statistics_geogrid.csv"


def extract_statistics():

    qcp = QCProperties()

    usedata = {
        "properties": PROPERTIES,
        "selectors": SELECTORS,
        "grid": GRID,
        "verbosity": 1,
    }
   #print(usedata['properties']['PORO']['weight'])

    qcp.get_grid_statistics(data=usedata, project=project)
    qcp.to_csv(REPORT)

if  __name__ == "__main__":
    extract_statistics()
    print("Done")