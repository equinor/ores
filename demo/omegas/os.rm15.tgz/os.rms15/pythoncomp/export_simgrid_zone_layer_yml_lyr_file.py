"""
Exports the zone->layer mapping on yml and lyr format.

The yml file is used in the xtgeo qc scripts GRID3D_HC_THICKNESS and
GRID3D_AVG_MAP.

The lyr file can be used as input to Resinsight and to the WellCompletions
Webviz plugin

OLIND & RNYB
"""
from pathlib import Path
from typing import Tuple
from fmu.config import utilities as ut

import xtgeo
CFG = ut.yaml_load("../../fmuconfig/output/global_variables.yml")
PRJ = project
GNAME = CFG["global"]["ECLGRIDNAME"]
PATH = "../../rms/output/zone/"
YML_FILENAME = "zonation_ecl_map.yml"
LYR_FILENAME = f"{GNAME}_zone_layer_mapping.lyr".lower()


def prepare_output_lines(subgrids) -> Tuple[list, list]:
    """Returns two lists of lines with the zone->layer mapping
    The first on yaml format and the second on lyr format
    """
    yml_lines = ["zranges:\n"]
    lyr_lines = [
        f"-- Zone layer mapping exported from RMS for the grid named {GNAME}\n"
    ]

    # loop zones
    for zone_name, zone_layers in subgrids.items():
        from_layer = zone_layers[0]
        to_layer = zone_layers[-1]
        yml_lines.append(f"  - {zone_name}: {[from_layer, to_layer]}\n")
        lyr_lines.append(f"'{zone_name}'    {from_layer} - {to_layer}\n")

    return yml_lines, lyr_lines


def write_lines_to_file(lines: list, filepath: Path):
    """Writes a list of lines to file"""
    with open(filepath, "w") as fout:
        fout.writelines(lines)
        print(f"Zone layer mapping written to file: {filepath}")


def main():
    # Create file Path objects
    yml_filepath = Path(PATH + YML_FILENAME)
    lyr_filepath = Path(PATH + LYR_FILENAME)

    # Create folder if it does not exist
    yml_filepath.parent.mkdir(parents=True, exist_ok=True)

    # load grid
    grd = xtgeo.grid_from_roxar(PRJ, GNAME)

    # prepare output lines
    yml_lines, lyr_lines = prepare_output_lines(grd.subgrids)

    # write to files
    write_lines_to_file(yml_lines, yml_filepath)
    write_lines_to_file(lyr_lines, lyr_filepath)


if __name__ == "__main__":
    main()
    print("Done")
