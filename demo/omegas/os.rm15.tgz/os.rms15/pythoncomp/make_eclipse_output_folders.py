"""
Make folders if they don't already exist.

JRIV
"""
import pathlib

DEST = pathlib.Path("../..") / "eclipse" / "include"

FOLDERS = [
    "runspec",
    "grid",
    "edit",
    "props",
    "solution",
    "regions",
    "schedule",
    "summary",
]


def main():
    """Make folders."""
    for folder in FOLDERS:
        path = DEST / folder
        try:
            path.mkdir(parents=True, exist_ok=False)
        except FileExistsError:
            print(f"Folder <{path}> is already there")
        else:
            print("Creating:", path)


if __name__ == "__main__":
    main()