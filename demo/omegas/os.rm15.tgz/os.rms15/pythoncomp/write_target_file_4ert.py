"""
 Running RMS in batch requires a target file at the end of 
 the workflow for ert to know if it was a success or failure

 rnyb, June 20
"""

target_file = "../../RMS_TARGET_MAIN"

with open(target_file, "w") as f:
    f.write("OK")

print("Created target file", target_file)
